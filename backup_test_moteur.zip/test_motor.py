from time import sleep
import RPi.GPIO as GPIO

DIR = 20   # Direction GPIO Pin
STEP = 21  # Step GPIO Pin
CW = 1     # Clockwise Rotation
CCW = 0    # Counterclockwise Rotation
SPR = 6400  # Steps per Revolution (360 / 7.5)


GPIO.setmode(GPIO.BCM)
GPIO.setup(DIR, GPIO.OUT)
GPIO.setup(STEP, GPIO.OUT)
GPIO.setup(12, GPIO.OUT)

GPIO.output(DIR, CW)

delay = 0.005 / 32

def turn(degree):
    delay = 0.005 / 32
    step_count = int((6400 / 360) * degree)
    GPIO.output(12, GPIO.LOW)
    for x in range(step_count):
        GPIO.output(STEP, GPIO.HIGH)
        sleep(delay)
        GPIO.output(STEP, GPIO.LOW)
        sleep(delay)

for i in range(0,12):
    turn(30)
    sleep(1)

GPIO.output(12, GPIO.HIGH)
GPIO.cleanup()
